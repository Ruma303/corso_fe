# Installazioni

1. Entrare con il terminale nella cartella
2. Eseguire il comando `npm install` per installare le dipendenze
4. Assicurarsi che il database MySQL sia attivo.
3. Eseguire il comando `node server.js` per avviare il server di sviluppo

# Creazione e test salvataggio utenti

- Questo comando creerà un server di sviluppo che ascolterà le richieste sulla porta 3000.
- Durante l'avvio del server verrà inviato automaticamente uno script per creare il database e le tabelle necessarie.
- Possiamo ora accedere all'applicazione aprendo il browser.
- Quando si crea un utente verrà salvato nel database MySQL.